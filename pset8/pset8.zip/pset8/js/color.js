var COLOR = 
{
    "Adams House": {color: "red"},
    "Cabot House": {color: "blue"},
    "Currier House": {color: "green"},
    "Dunster House": {color: "orange"},
    "Eliot House": {color: "yellow"},
    "Kirkland House": {color: "purple"},
    "Leverett House": {color: "black"},
    "Lowell House": {color: "red"},
    "Mather House": {color: "red"},
    "Pforzheimer House": {color: "red"},
    "Quincy House": {color: "green"},
    "Winthrop House": {color: "red"}
};
