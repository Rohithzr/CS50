<div class = "genform">
<form action="quote.php" method="post">
    <fieldset>
        <div class="form-group">
            <input class = "form-control" autofocus name="symbol" placeholder="Symbol" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Check</button>
        </div>
    </fieldset>
</form>
</div>



