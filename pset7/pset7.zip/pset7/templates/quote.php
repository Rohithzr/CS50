<?php

print("A share of ". $name. " (" . $symbol .") is $" . number_format($price, 2));

?>
