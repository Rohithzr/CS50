<div class = "genform">
<form action="deposit.php" method="post">
    <fieldset>
        <div class="form-group">
          
            <label for="depositamount">How much money would you like to deposit?</label>
            <input class = "form-control" autofocus name="deposit" id = "depositamount" placeholder="Deposit Amount (Dollars)" type="number"/>

        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Deposit</button>
        </div>
    </fieldset>
</form>
</div>
